tail -n 100 -f nohup.out
